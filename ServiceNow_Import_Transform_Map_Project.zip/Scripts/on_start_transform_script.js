(function runTransformScript(source, map, log, target) {

    // Ignore rows without a short description
    if (!source.short_description) {
        ignore = true;
        log.info("Row ignored: short_description is empty");
    }

})(source, map, log, target);
