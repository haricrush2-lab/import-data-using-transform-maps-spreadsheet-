(function transformRow(source, target, map, log, isUpdate) {

    // Default short description
    if (!source.short_description) {
        target.short_description = "Imported Record";
    }

    // Priority mapping
    if (source.priority == "1") {
        target.priority = "1";
    } else if (source.priority == "2") {
        target.priority = "2";
    } else {
        target.priority = "3";
    }

    // Copy category
    if (source.category) {
        target.category = source.category;
    }

})(source, target, map, log, action === "update");
