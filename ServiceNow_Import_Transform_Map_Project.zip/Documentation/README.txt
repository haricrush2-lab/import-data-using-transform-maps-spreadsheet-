SERVICENOW - IMPORT USING DATA + TRANSFORM MAP
===============================================

Project: Incident Spreadsheet Import

1. Prepare spreadsheet
----------------------
Use Spreadsheet/incident_import.xlsx or incident_import.csv.

Columns:
number
short_description
priority
caller
category

2. Create Import Set
--------------------
ServiceNow -> All -> System Import Sets -> Load Data
- Upload incident_import.xlsx
- Select file type: Excel
- Create a new import table
- Click Submit/Load

3. Create Transform Map
-----------------------
Go to:
System Import Sets -> Create Transform Map

Set:
- Import Set Table: the generated import table
- Target Table: Incident [incident]
- Name: Incident Spreadsheet Transform

4. Field Maps
-------------
Map source columns to target fields:

number              -> Number
short_description   -> Short description
priority            -> Priority
caller              -> Caller
category            -> Category

For Number, use Coalesce if you want existing records with the same
number to be updated instead of creating duplicates.

5. Transform Script
-------------------
Open the Transform Map -> Transform Scripts -> New.
Use Scripts/transform_script.js.

6. Optional OnStart script
--------------------------
Use Scripts/on_start_transform_script.js if rows without a
short description should be ignored.

7. Run Transform
----------------
Open the Import Set and click Transform.
Select the Transform Map.
Click Transform.

8. Verify
---------
Check:
- Import Set Rows
- Transform History
- Incident [incident] table

Expected sample records:
INC1001 - Laptop not working - Priority 1
INC1002 - Network issue - Priority 2
INC1003 - Software installation - Priority 3

NOTE:
The exact field availability (Caller, Category, Number) can depend on
your ServiceNow instance/configuration. If a reference field such as
Caller does not match by display value, create an appropriate reference
field map/coalesce strategy.
